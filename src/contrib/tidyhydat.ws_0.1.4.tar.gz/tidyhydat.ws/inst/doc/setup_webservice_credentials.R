## ------------------------------------------------------------------------
library(tidyhydat.ws)

## ---- echo=TRUE, eval=TRUE-----------------------------------------------
data("param_id")
param_id[1:4]

## ---- eval=FALSE---------------------------------------------------------
#  ## Get token
#  token_out <- token_ws()
#  
#  ## Input station_number, parameters and date range
#  ws_test <- realtime_ws(station_number = "08LG006",
#                         parameters = c(46,5), ## Water level and temperature
#                         start_date = "2017-06-25",
#                         end_date = "2017-07-24",
#                         token = token_out)

## ---- eval = FALSE-------------------------------------------------------
#  file.edit("~/.Renviron")

## ---- eval=FALSE---------------------------------------------------------
#  ## Credentials for ECCC web service
#  WS_USRNM = "here is the username that ECCC gave you"
#  WS_PWD = "here is the password that ECCC gave you"

