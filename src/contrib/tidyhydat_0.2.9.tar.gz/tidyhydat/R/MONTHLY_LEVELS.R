# Copyright 2017 Province of British Columbia
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
# http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and limitations under the License.

#' Extract monthly levels information from the HYDAT database
#'
#' Provides wrapper to turn the MONTHLY_LEVELS table in HYDAT into a tidy data frame.  \code{STATION_NUMBER} and
#'   \code{PROV_TERR_STATE_LOC} can both be supplied. If both are omitted all values from the \code{STATIONS} table are returned.
#'   That is a large vector for \code{MONTHLY_LEVELS}.
#'
#' @inheritParams STATIONS
#' @param start_date Leave blank if all dates are required. Date format needs to be in YYYY-MM-DD. Date is inclusive.
#' @param end_date Leave blank if all dates are required. Date format needs to be in YYYY-MM-DD. Date is inclusive.
#'
#' @return A tibble of monthly levels. This includes a \code{Date_occured} column which indicates the date of the \code{Sum_stat}. For MEAN and 
#'   TOTAL this is not presented as those are not daily values.
#'
#' @examples
#' \donttest{
#' MONTHLY_LEVELS(STATION_NUMBER = c("02JE013","08MF005"), hydat_path = "H:/Hydat.sqlite3",
#' start_date = "1996-01-01", end_date = "2000-01-01")
#'
#' MONTHLY_LEVELS(PROV_TERR_STATE_LOC = "PE", hydat_path = "H:/Hydat.sqlite3")
#'           }
#' @family HYDAT functions
#' @source HYDAT
#' @export



MONTHLY_LEVELS <- function(hydat_path=NULL, STATION_NUMBER = NULL, PROV_TERR_STATE_LOC = NULL, start_date ="ALL", end_date = "ALL") {
  if (!is.null(STATION_NUMBER) && STATION_NUMBER == "ALL") {
    stop("Deprecated behaviour.Omit the STATION_NUMBER = \"ALL\" argument. See ?MONTHLY_LEVELS for examples.")
  }

  if (start_date == "ALL" & end_date == "ALL") {
    message("No start and end dates specified. All dates available will be returned.")
  } else {
    ## When we want date contraints we need to break apart the dates because SQL has no native date format
    ## Start
    start_year <- lubridate::year(start_date)
    start_month <- lubridate::month(start_date)
    start_day <- lubridate::day(start_date)

    ## End
    end_year <- lubridate::year(end_date)
    end_month <- lubridate::month(end_date)
    end_day <- lubridate::day(end_date)
  }

  ## Check date is in the right format
  if (start_date != "ALL" | end_date != "ALL") {
    if (is.na(as.Date(start_date, format = "%Y-%m-%d")) | is.na(as.Date(end_date, format = "%Y-%m-%d"))) {
      stop("Invalid date format. Dates need to be in YYYY-MM-DD format")
    }

    if (start_date > end_date) {
      stop("start_date is after end_date. Try swapping values.")
    }
  }

  if (is.null(hydat_path)) {
    hydat_path <- Sys.getenv("hydat")
    if (is.na(hydat_path)) {
      stop("No Hydat.sqlite3 path set either in this function or 
           in your .Renviron file. See ?tidyhydat for more documentation.")
    }
  }


  ## Read in database
  hydat_con <- DBI::dbConnect(RSQLite::SQLite(), hydat_path)
  on.exit(DBI::dbDisconnect(hydat_con))

  ## Determine which stations we are querying
  stns <- station_choice(hydat_con, STATION_NUMBER, PROV_TERR_STATE_LOC)


  ## Data manipulations to make it "tidy"
  monthly_levels <- dplyr::tbl(hydat_con, "DLY_LEVELS")
  monthly_levels <- dplyr::filter(monthly_levels, STATION_NUMBER %in% stns)

  ## Do the initial subset to take advantage of dbplyr only issuing sql query when it has too
  if (start_date != "ALL" | end_date != "ALL") {
    monthly_levels <- dplyr::filter(monthly_levels, YEAR >= start_year &
      YEAR <= end_year)
    
    #monthly_levels <- dplyr::filter(monthly_levels, MONTH >= start_month &
    #                             MONTH <= end_month)
  }

  monthly_levels <- dplyr::select(monthly_levels, STATION_NUMBER:MAX)
  monthly_levels <- dplyr::collect(monthly_levels)
  
  ## Need to rename columns for gather
  colnames(monthly_levels) <- c("STATION_NUMBER","YEAR","MONTH", "PRECISION_CODE", "FULL_MONTH", "NO_DAYS", "MEAN_Value",
                           "TOTAL_Value", "MIN_DAY","MIN_Value", "MAX_DAY","MAX_Value")
  
  

  monthly_levels <- tidyr::gather(monthly_levels, variable, temp, -(STATION_NUMBER:NO_DAYS))
  monthly_levels <- tidyr::separate(monthly_levels, variable, into = c("Sum_stat","temp2"), sep = "_")

  monthly_levels <- tidyr::spread(monthly_levels, temp2, temp)

  ## convert into R date for date of occurence.
  monthly_levels <- dplyr::mutate(monthly_levels, Date_occurred = lubridate::ymd(paste0(YEAR, "-", MONTH, "-", DAY), quiet = TRUE))
  ## TODO: convert dates incorrectly. Make sure NA DAYs aren't converted into dates

  monthly_levels <- dplyr::select(monthly_levels, -DAY)
  monthly_levels <- dplyr::mutate(monthly_levels, FULL_MONTH = ifelse(FULL_MONTH == 1, "Yes", "No"))

  ## What stations were missed?
  differ <- setdiff(unique(stns), unique(monthly_levels$STATION_NUMBER))
  if (length(differ) != 0) {
    if (length(differ) <= 10) {
      message("The following station(s) were not retrieved: ", paste0(differ, sep = " "))
      message("Check station number typos or if it is a valid station in the network")
    }
    else {
      message("More than 10 stations from the initial query were not returned. Ensure realtime and active status are correctly specified.")
    }
  } else {
    message("All station successfully retrieved")
  }


  monthly_levels
}
