library(testthat)
library(tidyhydat)

test_check("tidyhydat")
