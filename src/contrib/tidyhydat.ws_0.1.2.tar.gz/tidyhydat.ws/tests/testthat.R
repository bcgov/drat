library(testthat)
library(tidyhydat.ws)

test_check("tidyhydat.ws")
