# bcgovr 0.1.3
* More consistent provision of README files in `analysis_skeleton()` and `package_skeleton()` (#19)
* Tidy formatting of README files

# bcgovr 0.1.2
* Making use of rstudioapi functions
* fixed small bug in `analysis_skeleton()` tests
* Now depends on rstudioapi >=0.7.0

# bcgovr 0.1.1

* Updated README with better instructions (#12)
* Added the ability to customize directory structure in `analysis_skeleton()` (#13)
* Fixed a bug where the `git_clone` argument in `analysis_skeleton()` and `package_skeleton()` didn't work (#14)
* Enhanced the **Insert BCDevex Badge** RStudio Addin (#15)

# bcgovr 0.1

* Initial release.



