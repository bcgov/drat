library(testthat)
library(bcgovr)
library(git2r)

test_check("bcgovr")
