# bcmaps.rdata 0.1.2
* Removed `watersheds` layer

# bcmaps.rdata 0.1.1

* Added ecosections
* Use gdb instead of shp as source for several layers - this resulted in more informative (but different) field names in those layers:
    - ecoregions
    - ecosections
    - ecoprovinces
    - gw_aquifers

# bcmaps.rdata 0.1.0

* Initial release
* Added a `NEWS.md` file to track changes to the package.



